#include "CosGUI.h"
#include <qtimer.h>
void CosGUI::initGUIcmps() {
	setLayout(mainLayout);
	
	
	mainLayout->addWidget(petsWidget);
}
void CosGUI::connectSignalsSlots() {
	QTimer* refreshTimer = new QTimer;
	QObject::connect(refreshTimer, &QTimer::timeout, [this]() {
		reloadList(cos.lista());
	});
	refreshTimer->start(1000);


}
void CosGUI::reloadList(const vector<Pet>& pets) {
	petsWidget->clear();
	for (const auto& p : pets) {
		QListWidgetItem* item = new QListWidgetItem(QString::fromStdString(p.getSpecies()));
		item->setData(Qt::UserRole, QString::fromStdString(p.getType()));
		if (p.getPrice() > 100) {
			item->setData(Qt::BackgroundRole, QBrush{ Qt::red, Qt::SolidPattern });
		}
		petsWidget->addItem(item);

	}
}