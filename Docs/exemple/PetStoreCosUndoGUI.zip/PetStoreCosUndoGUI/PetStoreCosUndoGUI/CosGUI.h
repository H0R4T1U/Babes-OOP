#pragma once
#include <QWidget.h>
#include "CosPet.h"
#include <QListWidget.h>
#include <QLayout.h>

class CosGUI : public QWidget {
private:
	CosPet& cos;
	void initGUIcmps();
	void connectSignalsSlots();
	void reloadList(const vector<Pet>& pets);

	QVBoxLayout* mainLayout = new QVBoxLayout;
	QListWidget* petsWidget = new QListWidget;

public:
	CosGUI(CosPet& c) : cos{ c } {
		initGUIcmps();
		connectSignalsSlots();
		reloadList(cos.lista());
	}
};